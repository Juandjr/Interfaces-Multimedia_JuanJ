document.addEventListener("DOMContentLoaded", () => {
    const images = document.querySelectorAll(".game-image");
    let currentIndex = 0;

    function updateGallery(index) {
        images.forEach((img, i) => {
            img.classList.toggle("active", i === index);
        });
    }

    document.getElementById("next").addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % images.length;
        updateGallery(currentIndex);
    });

    document.getElementById("prev").addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + images.length) % images.length;
        updateGallery(currentIndex);
    });

    updateGallery(currentIndex);
});

// Modal
document.addEventListener("DOMContentLoaded", function () {
    const modal = document.getElementById("videoModal");
    const btn = document.getElementById("openModal");
    const closeBtn = document.querySelector(".close");

    btn.addEventListener("click", function () {
        modal.style.display = "flex";
    });

    closeBtn.addEventListener("click", function () {
        modal.style.display = "none";
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const audio = new Audio("./Recursos/Clear Sky over Liyue.MP3");
    audio.loop = true;

    // Para iniciar el audio tras una interacción del usuario (requerido en algunos navegadores)
    document.body.addEventListener("click", function playAudio() {
        audio.play().catch(error => console.log("Autoplay bloqueado:", error));
        document.body.removeEventListener("click", playAudio);
    });
});
