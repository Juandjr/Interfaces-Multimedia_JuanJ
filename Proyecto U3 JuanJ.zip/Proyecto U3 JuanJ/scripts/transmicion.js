let screenStream;
        let cameraStream;

        document.getElementById('startScreenShare').addEventListener('click', async () => {
            try {
                screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
                const screenVideo = document.getElementById('screenVideo');
                screenVideo.srcObject = screenStream;
                screenVideo.style.display = 'block';
            } catch (error) {
                console.error('Error al compartir pantalla:', error);
            }
        });

        document.getElementById('startCamera').addEventListener('click', async () => {
            try {
                cameraStream = await navigator.mediaDevices.getUserMedia({ video: true });
                const cameraVideo = document.getElementById('cameraVideo');
                cameraVideo.srcObject = cameraStream;
                cameraVideo.style.display = 'block';
            } catch (error) {
                console.error('Error al activar la cámara:', error);
            }
        });

        document.getElementById('stopAll').addEventListener('click', () => {
            if (screenStream) {
                screenStream.getTracks().forEach(track => track.stop());
            }
            if (cameraStream) {
                cameraStream.getTracks().forEach(track => track.stop());
            }
            document.getElementById('screenVideo').srcObject = null;
            document.getElementById('cameraVideo').srcObject = null;
            document.getElementById('screenVideo').style.display = 'none';
            document.getElementById('cameraVideo').style.display = 'none';
        });